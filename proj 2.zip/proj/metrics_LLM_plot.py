import pandas as pd
import matplotlib.pyplot as plt
import os
from scipy.stats import spearmanr

# === Helper Functions ===

def minmax_scale(series):
    return (series - series.min()) / (series.max() - series.min()) if series.max() != series.min() else series

def save_plots_from_csv(read_file, eval_file, feature_set, task_type, window=5):
    # Load readability/complexity CSV (drop text column safely)
    with open(read_file, encoding="utf-8", errors="replace") as f:
        df_read = pd.read_csv(f)
    df_read.drop(df_read.columns[0], axis=1, inplace=True)  # DROP the first text column

    # Load evaluation Excel
    df_eval = pd.read_excel(eval_file)

    # Normalize IDs
    df_eval["match_id"] = df_eval["event_code"].str.replace("-", "_", regex=False).str.strip()
    df_read["label"] = df_read["label"].str.strip()

    # Merge on normalized IDs
    df = pd.merge(df_eval, df_read, left_on="match_id", right_on="label", how="inner")

    # Prepare output folder
    eval_base = os.path.splitext(os.path.basename(eval_file))[0]
    output_folder = rf"llm_f1_by_instance\{task_type}_{eval_base}"  # ONLY use task_type + evaluation filename
    os.makedirs(output_folder, exist_ok=True)

    reference = "ArgumentC-EM-F1"

    # Sort, smooth, and scale
    df_sorted = df.sort_values(reference).reset_index(drop=True)
    df_sorted[f"{reference}_smooth"] = df_sorted[reference].rolling(window=window, center=True).mean()
    df_sorted[f"{reference}_scaled"] = minmax_scale(df_sorted[f"{reference}_smooth"])
    x = range(len(df_sorted))

    for feature in feature_set:
        if feature not in df.columns:
            print(f"⚠️ Feature '{feature}' not found, skipping.")
            continue

        df_sorted[f"{feature}_smooth"] = df_sorted[feature].rolling(window=window, center=True).mean()
        df_sorted[f"{feature}_scaled"] = minmax_scale(df_sorted[f"{feature}_smooth"])

        # Calculate Spearman correlation
        valid_idx = df_sorted[[f"{reference}_smooth", f"{feature}_smooth"]].dropna().index
        spearman_corr, _ = spearmanr(
            df_sorted.loc[valid_idx, f"{reference}_smooth"],
            df_sorted.loc[valid_idx, f"{feature}_smooth"]
        )

        # Plot
        plt.figure(figsize=(10, 4))
        plt.plot(x, df_sorted[f"{reference}_scaled"], label=f"{reference} (scaled)", linewidth=2)
        plt.plot(x, df_sorted[f"{feature}_scaled"], label=f"{feature} (scaled)", linewidth=2)
        plt.title(f"{reference} vs {feature}\nSpearman Correlation: {spearman_corr:.2f}")
        plt.xlabel("Sorted Abstract Index (by ArgumentC-EM-F1)")
        plt.ylabel("Scaled Value (0–1)")
        plt.legend(fontsize=10)
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(os.path.join(output_folder, f"{reference}_vs_{feature}.png"))
        plt.close()

# === Feature Lists ===

readability_features = {
    'avg_word_length', 'avg_syllables', 'avg_age_of_acquisition',
    'avg_word_familiarity', 'flesch_reading_ease', 'gunning_fog',
    'connective_density', 'referential_cohesion', 'semantic_similarity'
}

complexity_features = {
    'TTR', 'MLTD', 'Entropy', 'AvgParseDepth', 'MaxParseDepth',
    'SubordClauseRatio', 'RecDepChainLen', 'AvgTUnitLength', 'ClausePerSentRatio'
}

# === Example Usage ===

# For readability
save_plots_from_csv(
    read_file=r"full_event_readability.csv",
    eval_file=r"llm_f1_by_instance\gpt_zero.xlsx",
    feature_set=readability_features,
    task_type="readability"
)

# For complexity
save_plots_from_csv(
    read_file=r"full_event_complexity.csv",
    eval_file=r"llm_f1_by_instance\gpt_zero.xlsx",
    feature_set=complexity_features,
    task_type="complexity"
)
