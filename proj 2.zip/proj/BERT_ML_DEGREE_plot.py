import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import spearmanr, pearsonr

# Load CSVs
csv1 = pd.read_csv("instance_eval_EM.csv")
csv2 = pd.read_csv("full_event_BERT.csv")

# Normalize IDs
csv1["match_id"] = csv1["wnd_id"].str.replace("-", "_", regex=False).str.strip()
csv2["label"] = csv2["label"].str.strip()

# Merge
df = pd.merge(csv1, csv2, left_on="match_id", right_on="label", how="inner")

# Rename and update to use ARG I
df = df.rename(columns={
    "Role_C_EM_F1": "role_c_f1",
    "readability score": "complexity_score",
    "complexity score": "readability_score"
})
df["readability_inverted"] = 11 - df["readability_score"]

# --- Rescaling function ---
def rescale(series, new_min, new_max):
    return new_min + (new_max - new_min) * ((series - series.min()) / (series.max() - series.min()))

# Scale Role_C_EM_F1 separately for each plot
df["f1_for_complexity"] = rescale(df["role_c_f1"], 6, 8)
df["f1_for_readability"] = rescale(df["role_c_f1"], 5, 7)

# Sort by ARG I F1
df = df.sort_values("role_c_f1").reset_index(drop=True)

# Apply smoothing
window = 5
df["f1_for_complexity_smooth"] = df["f1_for_complexity"].rolling(window, center=True).mean()
df["complexity_smooth"] = df["complexity_score"].rolling(window, center=True).mean()

df["f1_for_readability_smooth"] = df["f1_for_readability"].rolling(window, center=True).mean()
df["readability_smooth"] = df["readability_inverted"].rolling(window, center=True).mean()

x = range(len(df))

# --- Plotting ---
plt.figure(figsize=(14, 6))

# Plot 1: F1 vs Complexity
plt.subplot(1, 2, 1)
plt.plot(x, df["f1_for_complexity_smooth"], label="ARG_I_EM_F1 (scaled 6–8, smoothed)", linewidth=2)
plt.plot(x, df["complexity_smooth"], label="Complexity (smoothed)", linewidth=2)
plt.title("DEGREE ARG C F1 vs BERT Complexity")
plt.xlabel("Sorted by ARG_C_EM_F1")
plt.ylabel("Score")
plt.legend()
plt.grid(True)

# Plot 2: F1 vs Readability
plt.subplot(1, 2, 2)
plt.plot(x, df["f1_for_readability_smooth"], label="ARG_I_EM_F1 (scaled 5–7, smoothed)", linewidth=2)
plt.plot(x, df["readability_smooth"], label="Readability (inverted, smoothed)", linewidth=2)
plt.title("DEGREE ARG C F1 vs BERT Readability (Inverted)")
plt.xlabel("Sorted by ARG_C_EM_F1")
plt.ylabel("Score")
plt.legend()
plt.grid(True)

plt.tight_layout()
plt.show()

# --- Correlation (optional diagnostic) ---
df_corr = df.dropna()
spear_c, _ = spearmanr(df_corr["role_c_f1"], df_corr["complexity_score"])
spear_r, _ = spearmanr(df_corr["role_c_f1"], df_corr["readability_inverted"])
print(f"📊 Spearman Correlation — ARG_I_EM_F1 vs Complexity: {spear_c:.2f}")
print(f"📊 Spearman Correlation — ARG_I_EM_F1 vs Readability: {spear_r:.2f}")
