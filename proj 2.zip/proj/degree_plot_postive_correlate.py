import pandas as pd
import matplotlib.pyplot as plt
import os

# === Settings ===
input_file = "instance_eval_EM.csv"
output_folder = "arg_class_comparisons"
os.makedirs(output_folder, exist_ok=True)

# === Load data and prepare ===
df = pd.read_csv(input_file)
df["match_id"] = df["wnd_id"].str.replace("-", "_", regex=False).str.strip()

# === Target comparisons ===
reference = "Role_C_EM_F1"
comparisons = ["Trigger_I_EM_F1", "Trigger_C_EM_F1", "Role_I_EM_F1"]
window = 5

# === Helper ===
def minmax_scale(series):
    return (series - series.min()) / (series.max() - series.min()) if series.max() != series.min() else series

# === Preprocess ===
df_sorted = df.sort_values(reference).reset_index(drop=True)
df_sorted[f"{reference}_smooth"] = df_sorted[reference].rolling(window=window, center=True).mean()
df_sorted[f"{reference}_scaled"] = minmax_scale(df_sorted[f"{reference}_smooth"])
x = range(len(df_sorted))

# === Plot comparisons ===
for metric in comparisons:
    df_sorted[f"{metric}_smooth"] = df_sorted[metric].rolling(window=window, center=True).mean()
    df_sorted[f"{metric}_scaled"] = minmax_scale(df_sorted[f"{metric}_smooth"])

    plt.figure(figsize=(10, 4))
    plt.plot(x, df_sorted[f"{reference}_scaled"], label=f"{reference} (scaled)", linewidth=2)
    plt.plot(x, df_sorted[f"{metric}_scaled"], label=f"{metric} (scaled)", linewidth=2)
    plt.title(f"{reference} vs {metric}")
    plt.xlabel("Sorted Abstract Index (by Role_C_EM_F1)")
    plt.ylabel("Scaled Value (0–1)")
    plt.legend(fontsize=10)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, f"{reference}_vs_{metric}.png"))
    plt.close()
