import pandas as pd
import matplotlib.pyplot as plt
import os
from scipy.stats import spearmanr

# === Load files ===

# csv2: feature file (still CSV)
csv2 = pd.read_csv(r"full_event_BERT.csv")

# csv1: evaluation file (Excel now)
eval_file = r"llm_f1_by_instance\gpt_one.xlsx"

csv1 = pd.read_excel(eval_file)

# === Normalize IDs ===
csv1["match_id"] = csv1["event_code"].str.replace("-", "_", regex=False).str.strip()
csv2["label"] = csv2["label"].str.strip()

# === Merge ===
df = pd.merge(csv1, csv2, left_on="match_id", right_on="label", how="inner")

# === Rename and Prepare Columns ===
df = df.rename(columns={
    "ArgumentC-EM-F1": "role_c_f1",  
    "readability score": "complexity_score",
    "complexity score": "readability_score"
})

# Invert readability (higher = harder)
df["readability_inverted"] = 11 - df["readability_score"]

# === Rescaling function ===
def rescale(series, new_min, new_max):
    return new_min + (new_max - new_min) * ((series - series.min()) / (series.max() - series.min()))

# Scale Role_C_EM_F1 separately
df["f1_for_complexity"] = rescale(df["role_c_f1"], 6, 8)
df["f1_for_readability"] = rescale(df["role_c_f1"], 5, 7)

# === Sort by role_c_f1
df = df.sort_values("role_c_f1").reset_index(drop=True)

# === Smoothing (rolling window)
window = 5
df["f1_for_complexity_smooth"] = df["f1_for_complexity"].rolling(window, center=True).mean()
df["complexity_smooth"] = df["complexity_score"].rolling(window, center=True).mean()

df["f1_for_readability_smooth"] = df["f1_for_readability"].rolling(window, center=True).mean()
df["readability_smooth"] = df["readability_inverted"].rolling(window, center=True).mean()

x = range(len(df))

# === Correlation calculation ===
df_corr = df.dropna()

spear_c, _ = spearmanr(df_corr["role_c_f1"], df_corr["complexity_score"])
spear_r, _ = spearmanr(df_corr["role_c_f1"], df_corr["readability_inverted"])

# === Prepare output folder
eval_base = os.path.splitext(os.path.basename(eval_file))[0]
output_folder = rf"llm_f1_by_instance\BERT_{eval_base}"
os.makedirs(output_folder, exist_ok=True)

# === Plot 1: F1 vs Complexity ===
plt.figure(figsize=(10, 5))
plt.plot(x, df["f1_for_complexity_smooth"], label="ARG_C_EM_F1 (scaled 6–8, smoothed)", linewidth=2)
plt.plot(x, df["complexity_smooth"], label="Complexity (smoothed)", linewidth=2)
plt.title(f"ARG_C_EM_F1 vs BERT Complexity\nSpearman Correlation: {spear_c:.2f}")
plt.xlabel("Sorted Abstract Index (by ARG_C_EM_F1)")
plt.ylabel("Score")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig(os.path.join(output_folder, "ARGC_vs_Complexity.png"))
plt.close()

# === Plot 2: F1 vs Readability ===
plt.figure(figsize=(10, 5))
plt.plot(x, df["f1_for_readability_smooth"], label="ARG_C_EM_F1 (scaled 5–7, smoothed)", linewidth=2)
plt.plot(x, df["readability_smooth"], label="Readability (inverted, smoothed)", linewidth=2)
plt.title(f"ARG_C_EM_F1 vs BERT Readability (Inverted)\nSpearman Correlation: {spear_r:.2f}")
plt.xlabel("Sorted Abstract Index (by ARG_C_EM_F1)")
plt.ylabel("Score")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig(os.path.join(output_folder, "ARGC_vs_Readability.png"))
plt.close()
