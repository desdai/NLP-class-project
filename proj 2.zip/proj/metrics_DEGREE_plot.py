import pandas as pd
import matplotlib.pyplot as plt
import os

# === Load Evaluation CSV ===
csv1 = pd.read_csv("instance_eval_EM.csv")
csv1["match_id"] = csv1["wnd_id"].str.replace("-", "_", regex=False).str.strip()
csv1_subset = csv1[["match_id", "Role_C_EM_F1"]]

# === Load Readability & Complexity CSVs (drop text column) ===
def safe_load_without_first_column(path):
    with open(path, encoding="utf-8", errors="replace") as f:
        df = pd.read_csv(f)
    df.drop(df.columns[0], axis=1, inplace=True)
    df["label"] = df["label"].str.strip()
    return df

csv2 = safe_load_without_first_column("full_event_readability.csv")
csv3 = safe_load_without_first_column("full_event_complexity.csv")

# === Merge by label ===
df_read = pd.merge(csv1_subset, csv2, left_on="match_id", right_on="label", how="inner")
df_comp = pd.merge(csv1_subset, csv3, left_on="match_id", right_on="label", how="inner")

# === Final feature sets ===
readability_features = {
    'avg_word_length', 'avg_syllables', 'avg_age_of_acquisition',
    'avg_word_familiarity', 'flesch_reading_ease', 'gunning_fog',
    'connective_density', 'referential_cohesion', 'semantic_similarity'
}

complexity_features = {
    'TTR', 'MLTD', 'Entropy', 'AvgParseDepth', 'MaxParseDepth',
    'SubordClauseRatio', 'RecDepChainLen', 'AvgTUnitLength', 'ClausePerSentRatio'
}

# === Scaling helper ===
def minmax_scale(series):
    return (series - series.min()) / (series.max() - series.min()) if series.max() != series.min() else series

# === Save smoothed and scaled plots ===
def save_smoothed_scaled_plots(df, f1_col, folder_name, feature_set, invert_readability=False, window=5):
    os.makedirs(folder_name, exist_ok=True)

    df_sorted = df.sort_values(f1_col).reset_index(drop=True)
    df_sorted[f"{f1_col}_smooth"] = df_sorted[f1_col].rolling(window=window, center=True).mean()
    df_sorted[f"{f1_col}_scaled"] = minmax_scale(df_sorted[f"{f1_col}_smooth"])
    x = range(len(df_sorted))

    for feature in feature_set:
        if feature not in df.columns:
            print(f"⚠️ Feature '{feature}' not found, skipping.")
            continue

        df_sorted[f"{feature}_smooth"] = df_sorted[feature].rolling(window=window, center=True).mean()

        if invert_readability:
            df_sorted[f"{feature}_smooth"] = df_sorted[f"{feature}_smooth"].max() - df_sorted[f"{feature}_smooth"]

        df_sorted[f"{feature}_scaled"] = minmax_scale(df_sorted[f"{feature}_smooth"])

        plt.figure(figsize=(10, 4))
        plt.plot(x, df_sorted[f"{f1_col}_scaled"], label=f"{f1_col} (scaled)", linewidth=2)
        plt.plot(x, df_sorted[f"{feature}_scaled"], label=f"{feature} (scaled)", linewidth=2)
        plt.title(f"{folder_name}: {f1_col} vs {feature}")
        plt.xlabel("Sorted Abstract Index (by F1)")
        plt.ylabel("Scaled Value (0–1)")
        plt.legend(fontsize=10)
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(os.path.join(folder_name, f"{feature}.png"))
        plt.close()

# === Run and Save Plots ===
save_smoothed_scaled_plots(df_read, "Role_C_EM_F1", "readability_plots", readability_features, invert_readability=True)
save_smoothed_scaled_plots(df_comp, "Role_C_EM_F1", "complexity_plots", complexity_features, invert_readability=False)
