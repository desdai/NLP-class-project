import pandas as pd
import matplotlib.pyplot as plt
import os
from scipy.stats import spearmanr

# Load Excel
# input_file = r"llm_f1_by_instance\llama_one.xlsx"
# output_folder = r"llm_f1_by_instance\llama_one"

input_file = r"llm_f1_by_instance\gpt_one.xlsx"
output_folder = r"llm_f1_by_instance\gpt_one"
os.makedirs(output_folder, exist_ok=True)

df = pd.read_excel(input_file)

# Settings
reference = "ArgumentC-EM-F1"
comparisons = ["TriggerI-EM-F1", "ArgumentI-EM-F1"]
window = 5

# Helper
def minmax_scale(series):
    return (series - series.min()) / (series.max() - series.min()) if series.max() != series.min() else series

# Sort and smooth
df_sorted = df.sort_values(reference).reset_index(drop=True)
df_sorted[f"{reference}_smooth"] = df_sorted[reference].rolling(window=window, center=True).mean()
df_sorted[f"{reference}_scaled"] = minmax_scale(df_sorted[f"{reference}_smooth"])
x = range(len(df_sorted))

# Plot comparisons
for metric in comparisons:
    df_sorted[f"{metric}_smooth"] = df_sorted[metric].rolling(window=window, center=True).mean()
    df_sorted[f"{metric}_scaled"] = minmax_scale(df_sorted[f"{metric}_smooth"])

    # Calculate Spearman correlation (after smoothing)
    valid_idx = df_sorted[[f"{reference}_smooth", f"{metric}_smooth"]].dropna().index
    spearman_corr, _ = spearmanr(
        df_sorted.loc[valid_idx, f"{reference}_smooth"],
        df_sorted.loc[valid_idx, f"{metric}_smooth"]
    )

    plt.figure(figsize=(10, 4))
    plt.plot(x, df_sorted[f"{reference}_scaled"], label=f"{reference} (scaled)", linewidth=2)
    plt.plot(x, df_sorted[f"{metric}_scaled"], label=f"{metric} (scaled)", linewidth=2)
    plt.title(f"{reference} vs {metric}\nSpearman Correlation: {spearman_corr:.2f}")
    plt.xlabel("Sorted Abstract Index (by ArgumentC-EM-F1)")
    plt.ylabel("Scaled Value (0–1)")
    plt.legend(fontsize=10)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, f"{reference}_vs_{metric}.png"))
    plt.close()
