import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from scipy.cluster.hierarchy import linkage, dendrogram
import numpy as np

# Load the Excel file
file_path = "complexityfeatures.xlsx"
df = pd.read_excel(file_path)

# Drop non-numeric columns if any (e.g., 'Labels')
numeric_df = df.select_dtypes(include=[np.number])

# 1. Correlation Heatmap
plt.figure(figsize=(12, 10))
sns.heatmap(numeric_df.corr(), annot=True, cmap='coolwarm', center=0, fmt=".2f")
plt.title("Correlation Heatmap of Linguistic Metrics")
plt.tight_layout()
plt.show()

# 2. Pairplot for a subset (to avoid overwhelming visuals)
subset_cols = numeric_df.columns[:]  # Adjust as needed
sns.pairplot(numeric_df[subset_cols])
plt.suptitle("Pairwise Scatterplot of Selected Metrics", y=1.02)
plt.show()

# 3. PCA Plot
scaler = StandardScaler()
X_scaled = scaler.fit_transform(numeric_df)

pca = PCA(n_components=2)
pca_result = pca.fit_transform(X_scaled)

plt.figure(figsize=(8, 6))
plt.scatter(pca_result[:, 0], pca_result[:, 1])
plt.xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}%)")
plt.ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}%)")
plt.title("PCA of Linguistic Metrics")
plt.grid(True)
plt.tight_layout()
plt.show()

# 4. Dendrogram
linked = linkage(X_scaled.T, method='ward')  # Transpose to cluster features not samples

plt.figure(figsize=(10, 6))
dendrogram(linked, labels=numeric_df.columns, orientation='top', distance_sort='descending')
plt.title("Dendrogram of Feature Clustering")
plt.tight_layout()
plt.show()
